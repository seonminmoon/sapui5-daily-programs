sap.ui.define([
	"sapbtp/ex_project/test/unit/controller/App.controller"
], function () {
	"use strict";
});
