/* global QUnit */

sap.ui.require(["sap/btp/exproject/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
