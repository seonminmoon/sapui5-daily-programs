sap.ui.define([
	"test0000/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
