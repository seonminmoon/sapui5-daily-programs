/* global QUnit */

sap.ui.require(["test0000/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
